package com.qa.raybiztech.utils;

public class Constants {
	
	public static final String Home_Page_Title = "A, Dynamics 365 ERP & CRM, Kentico, Sitecore, Dell Boomi-RBT";
	public static final int Default_Time_Out = 5;
	
	public static final String ArtificialIntelligence_Page_Title = "Artificial Intelligence Services - Ray Business Technologies";
	
	public static final String Contacts_Sheet_Name = "contact";
}
